$('input').change(function(){
	var keyword = $('input').val();
	//console.log('k is '+keyword);
	if (!keyword) {
	$('.title').parent().show()
	}
	 $('.title').each(function(){
	    var text = $(this).text();
		if (_.includes(text,keyword)) {
		
			$(this).parent().show();
		}
		else {
			$(this).parent().hide();
		}		
	})
})
$('.reset').click(function(){
	$('input').val('');
	$('.title').parent().show();
})
